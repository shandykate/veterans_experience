jQuery(document).ready(function () {
    $(".header--menu__link").mPageScroll2id({scrollSpeed: 800 });
    // $("button a").mPageScroll2id({scrollSpeed: 800});
});