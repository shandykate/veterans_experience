jQuery(document).ready(function () {
    $(".header-link").mPageScroll2id({scrollSpeed: 800 });
    // $("button a").mPageScroll2id({scrollSpeed: 800});
});